# Team Briefing
## Viksit Nagpur Hackathon 2026 — what we're building and why

*Read time ~12 minutes. The reasoning is included, not just the conclusions, because you'll be asked "why" by judges and you need to answer without help.*

> **Working rule for this project: no feature enters scope until the data behind it is named and the logic is verified.** Every claim in here is traced to a source. Where the data doesn't support a claim, we don't make it. The companion **Data Audit** document has the feature-by-feature trace.

---

## 1. What we're walking into

- **17–18 August, VNIT Nagpur.** Theme: **Open Innovation** — we define our own problem.
- Coding: 10:00 AM 17th → 10:00 AM 18th. **24 hours.**
- Pitch noon on the 18th: **3 minutes strictly, then 3 minutes of jury Q&A.**
- 5 members. Deck is 6–7 slides maximum.
- Judges include **VNIT professors** (technical claims get tested) **and municipal people** (deployability gets tested).

---

## 2. The topic, in one sentence

> **Water in Nagpur — is it safe to use, who does it affect, and is anyone fixing it.**

---

## 3. The problem

The obvious version of this project is "Nagpur has water problems, nobody has data, we'll build a dashboard." That's what most water teams will pitch, and it's wrong.

**Nagpur's water *is* measured:**

- **OCW** (the operator running city supply) publishes sample results — current to **May 2026**, 99.6% fit
- **CGWB** has sampled district groundwater — 263 shallow and 84 deep points, with village names
- **MPCB** monitors the Nag and Pili and mapped every sewage outfall

**But:** OCW publishes **one number for three million people**. CGWB's results sit as scattered points in a PDF no resident will open. MPCB's river data comes from **5 stations**, dated 2009–11.

> ### Our problem statement
> **No resident of Nagpur can reach an answer to "is my water safe?" at the resolution they live at.**

**Two things about this wording, and both matter.**

First, it does **not** accuse anyone of negligence. OCW is testing. CGWB is sampling. The gap is resolution and connection, not effort. Sound like we're calling the utility incompetent and we lose the municipal half of the room in ten seconds.

Second — and this is a correction we made deliberately — we say **"no resident can reach it,"** not "it doesn't exist." Unpublished is not the same as non-existent. Zone-level records plausibly sit inside NMC or OCW, and **the person best placed to say "we have that, you didn't ask" may be on our panel.** If that happens, it's a win, not a collapse: *"If that data exists, we'd take the feed tomorrow. This is the front end for it — that's our ask."*

**And the structural reason this gap exists:** the three datasets belong to a municipal operator, a state board and a central board. **No single one of them can produce this picture alone.** That's a real answer to "why hasn't anyone done this."

---

## 4. What we're building

**Three questions. Q1 is the project; Q2 and Q3 are built around it.**

### Q1 — Is this water safe, and what for? *(the core)*

Four sources covered: **municipal tap, borewell/groundwater, river or nala, canal.**

**1. Where does your water come from?** Source, treatment plant, supply type.
> ⚠️ The area→reservoir mapping isn't published. **Fallback decided in advance:** degrade to NMC administrative zones, say "your zone", label it approximate. **If we don't have reservoir command areas by hour 2, we ship zones and move on.** No hunting PDFs during the build.

**2. Usability verdict — and we never say "safe."**

We have chemistry (nitrate, fluoride, EC, pH, hardness, chloride). We have **zero bacteriological data**, and IS 10500 requires absence of E. coli and coliforms for potability. So the verdict is **asymmetric**, three states only:

- ① *Exceeds the IS 10500 limit for [parameter], measured [date], [distance] away*
- ② *No exceedance among the [n] parameters tested here — **not tested for bacteriological quality***
- ③ *Not tested*

**None of those is "safe."** This removes our liability exposure, matches our integrity slide, and refusing to say "safe" when we can't is the single strongest credibility move available to us.

**3. Crop verdict** — water EC and pH against **FAO-29** crop salt-tolerance tables → yield-loss estimate, and what to grow or how to blend. Our strongest feature.
> ⚠️ FAO tables come in ECe (soil extract) and ECw (irrigation water). **Use the ECw column and state the leaching assumption.** Mixing them silently is the one place this feature can be attacked. And read the actual thresholds from the table — don't reuse any percentage from earlier drafts.

**4. A map of what is actually known** — every real measurement as a point, with date and distance. **We never draw a smooth colour surface**; at this density, interpolation invents knowledge, which is the exact sin we're pointing at.

**5. Which outfalls are upstream of you** — all **12 outfall locations are named and geocodable** (9 on the Nag, 3 on the Pili).
> ⚠️ **No discharge volume exists for any individual outfall**, and only 3 stations sit on the Nag. So this is **segment-level attribution, not outfall-level.** We can say "these 3 outfalls are upstream of you" and "BOD rises from 4–13 at Ambazari to ~57 at Bhandewadi — these are the outfalls in between." We can never say outfall X contributes Y%.

**6. Citizen sample entry — correctly scoped.** A TDS meter is a conductivity probe. It **cannot** detect nitrate, fluoride, coliforms or metals — none of the contaminants we lead with. What it legitimately gives us:
- **Irrigation screening** — FAO irrigation limits are largely EC-based, so the crop verdict genuinely runs on a ₹300 meter
- **Change detection** — *"your borewell's TDS is up 40% since last reading, get it lab-tested"*

Citizen readings **never** produce a potability verdict. The entry screen states what the instrument can and cannot detect.

### Q2 — Which areas suffer, and how badly, for a given amount of rain?

**Ordinal rank, not a number.** *"This junction is in the top 5% of the city for ponding risk given its catchment area, drain density and sink depth."*

> ⚠️ We nearly shipped *"floods above 40 mm"* — which is exactly the labelled dataset we said doesn't exist. That number would be invented or self-generated, both of which we declared indefensible in our own document. Ordinal is what the DEM and OSM network actually support.

> ⚠️ **Never put the word "route" next to the word "Maps."** We rejected safe-route navigation because it invites the comparison — so we don't then lead with the comparison. Our defensible claim is timing: **we warn before, not during.**

### Q3 — Is anyone fixing it?

Crowdsourced: residents report whether work is happening, plus a **30-day follow-up asking whether it was actually fixed** — a question almost no complaint system in India asks.

> ⚠️ It's our most original idea, it's last in the queue, and **a 30-day loop cannot be demonstrated in three minutes.** Decide before the 17th: either **don't build it** and give it one spoken sentence, or **build only the follow-up mechanic** on seeded data with shifted timestamps and demo it as a time-travel view. Leaving it as "then Q3" turns our best idea into a screenshot, which reads as vapour.

---

## 5. The facts we stand on

**Water supply**
- **190 MCM/year (~520 MLD)** from Pench — over 70% of city supply
- **68 reservoirs, 2000+ km of pipeline, 3M+ consumers**
- The extra 78 MCM granted in 2000 cut the **irrigation command area by 8,658 hectares**

**Sewage and the river**
- **345 MLD generated · 100 MLD plant capacity running at 80% → ~80 MLD treated → ~265 MLD untreated** *(2011 figures. Someone must verify current capacity on 16 Aug — Bhandewadi has expanded. If unverified, drop it from the spoken pitch and let the BOD gradient carry the argument.)*
- **9 outfalls into the Nag, 3 into the Pili** — all named and locatable
- Nag rises at the **Ambazari overflow weir**, 17 km through the city, ~68 km to the Kanhan at Agargaon, past **31 villages**
- **BOD: 4–13 mg/L at the origin → averaging 57, peaking at 124 at Bhandewadi Bridge.** The river doesn't arrive polluted; the city does that to it over 17 km. **This is our best number — it's vivid and nobody can correct it.**

**Groundwater (CGWB district-wide)**
- Nitrate above limit in **35 of 263 shallow** and **17 of 84 deep** samples
> ⚠️ Do **not** claim "deep is worse." Unpaired samples, n=263 vs 84 → z ≈ 1.55, p ≈ 0.12, confidence intervals overlap heavily. It survives only as: *"in this dataset deep samples exceeded more often — the samples aren't paired, so it's a question worth asking, not a conclusion."*
- Fluoride up to **4.4 mg/L** at Sukali Gharapure, Hingna
- Salinity above the irrigation limit in **5.3%** of shallow samples; **4920 µS/cm at Belgaon, Umred**
- **65 of 72 stations show falling pre-monsoon water levels**

**Flooding**
- 24 Sept 2023: **109 mm overnight, 4 deaths, ~10,000 houses**, a bridge collapsed
- **₹266.63 crore** mitigation package announced afterwards

**Policy**
- **NDMA Urban Flooding Guidelines (2010)** already require GIS drainage inventories, catchment-based planning and desilting by 31 March, for every Indian city. Sixteen years on it hasn't happened — it assumes a survey no city can fund.

---

## 6. What we are deliberately NOT building

| Not building | Why |
|---|---|
| ML prediction | No labelled flood dataset for Nagpur. Training on data we generated ourselves is our own assumptions with invented error bars |
| Disease forecasting | Not calibrated to local health data — a guess in a lab coat |
| Recharge site selection | Soil maps are ~1:250,000. You cannot site anything at that resolution |
| Safe-route navigation | Google does it better and building it invites the comparison |
| Multi-utility coordination | Different domain, unobtainable data |
| Smooth interpolated quality maps | Would invent knowledge we don't have — the exact thing we criticise |

If a judge raises any of these, the answer is never "we didn't think of it."

---

## 7. What we claim, and what we refuse to claim

We do **not** say "fluid dynamics" or "flood simulation." Nobody does CFD for city drainage. The correct term is **screening-level analysis** — the triage real consultants do before detailed modelling.

> **"We're not replacing SWMM. This is screening — which twenty locations out of two thousand deserve a proper look. The output is a priority ranking, not a design discharge."**

**We never claim:**
- That any water is **safe to drink** — we have no bacteriological data
- Flood depth, or any numeric rainfall threshold
- Attribution of pollution to a single outfall
- Lab-grade quality at any point we haven't measured
- Design-grade numbers anyone should build from

**We do claim:** a ranked, reproducible screening of where the water system is most likely to fail, and a location-specific reading of what *is* known about your water, at the resolution the data actually supports.

**And we volunteer our own weaknesses before anyone finds them.** A team that names its own failure modes gets trusted on everything else.

---

## 8. The demo trap, and how we handle it

**The sharpest question we will get:** *"You attack OCW for publishing one number for three million people. But your map is grey almost everywhere. How is your 'we don't know' better than theirs?"*

**The answer is a demo move, not an argument.** Don't pitch the map — **pitch the instrument.** On stage, enter a reading and watch a grey cell resolve into a verdict. The map is the *before*; the demo shows the *after*.

And change the line. Not *"the grey is the finding"* — instead:

> **"The grey isn't the finding. It's the worklist. And here's what it costs to fill one cell."**

Script this moment deliberately: show one measured point, then immediately show a grey one and say the line **before** a judge can ask.

---

## 9. Architecture — because "what was technically hard?" is what professors score

Three non-trivial pieces. One sentence each, know them cold:

1. **The upstream-outfall spatial join** — determining which of 12 outfalls lie upstream of an arbitrary point along a river network built from OSM geometry
2. **The multi-standard verdict engine** — reconciling IS 10500, CPCB Class A–E and FAO-29, which use different parameters, units and thresholds, into one answer without silently mixing them
3. **DEM-based sink and catchment delineation** for the Q2 ordinal ranking

"We joined a spreadsheet to a map" scores badly against a 24-hour engineering brief. These three sentences are the answer.

---

## 10. The ask — end the pitch here, not on the map

Municipal officials respond far better to being asked for something concrete than to being shown a dashboard.

- **Runs on** free tiers, low monthly cost — the twin is compute, not capital
- **Citizen data is moderated:** visually distinct from official readings, requires corroborating readings before display, never produces a "safe" verdict — only "get this tested"
- **What we're asking for:** a **zone-level quality feed from OCW**, and **read access to NMC works data**

---

## 11. Still open

1. **Which reservoir serves which area** — highest-value unknown. Fallback to zones is already decided
2. **Current sewage treatment capacity** — the 2011 figure needs verifying or dropping
3. **Q3 build-or-speak** — decide on the 16th, not during the build
4. **Whether to write to NMC/OCW on the 16th** — being able to say *"we wrote to them on Saturday"* changes the room

---

## 12. Timeline

**16 August.** Collect everything: downloads, r/nagpur harvesting, OCW table into a spreadsheet, OSM export saved locally, the 12 outfalls geocoded by hand, photos of spots we know clog. **Data collection is not coding.** Everything on a drive by 10 AM on the 17th is worth six hours.

**17 August, hours 0–18.** Build. Q1 first and completely, then Q2.

**Hour 18 — feature freeze. Non-negotiable.**

**Hours 18–24.** Integration, demo data, deck, and rehearsing the three minutes at least six times.

**Demo safety:** cache every API response and pin map tiles locally — 40 teams will be on that Wi-Fi at noon. Record a 60-second screen capture as a fallback and keep it open in a second tab. Replace free-text location entry with a dropdown of ~20 Nagpur localities. Two speakers maximum in three minutes.

---

## 13. The lines to remember

> **"Nagpur tests its water and publishes one number for three million people."**

> **"The grey isn't the finding — it's the worklist."**

> **"We're not measuring new things. We're connecting what's already measured to the person it affects."**

> **"We will not tell you your water is safe. We'll tell you exactly what is known about it, and what isn't."**
