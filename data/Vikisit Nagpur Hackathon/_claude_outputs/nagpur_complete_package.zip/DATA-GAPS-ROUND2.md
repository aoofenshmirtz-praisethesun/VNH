# Data: what the ESR maps actually give you, and what's still missing

---

## 1. The ESR maps are not "just supply" — they're the best thing in the folder

You asked whether supply is all they give. It isn't. Each of the 37 maps carries **four** things:

| On the map | Why it matters |
|---|---|
| **ESR command-area boundary** | This is the F1 unlock — which reservoir serves which area |
| **Supply zones** (SZ-1 … SZ-20 per ESR) | Sub-zone granularity *inside* each command area |
| **Supply hours, colour-coded** — 18-24 / 04-08 / **02-04 hours** | ⭐ See below |
| **Folder structure** = ESR → NMC zone | 37 ESRs mapped to 10 NMC zones, free |

### The supply-hours layer is the find

Some parts of Nagpur get **18 to 24 hours** of water. Others get **2 to 4 hours**. Both appear inside a single ESR's command area — Khamla alone spans all three bands.

Two reasons this matters more than it looks:

**It's the inequality map.** "Which parts of this city get water for 2 hours a day and which get 24" is immediately understandable to any judge, needs no explanation, and as far as I can tell **does not exist anywhere as data** — only as 37 separate PDF pictures.

**It's a contamination risk proxy, with peer-reviewed local backing.** The published Nagpur research on the shift from intermittent to continuous supply found microbial quality improves with 24x7 — because pipes that sit empty between supply hours draw contaminated water in through leaks. So a 2-4 hour zone isn't just inconvenient, it's a *risk indicator*. That links the supply map directly to Q1.

---

## 2. What I could and couldn't extract — stated honestly

**Extractable automatically, reliable:**
- ESR name, NMC zone, and the full list of supply-zone codes per ESR
- **Blue (04-08 hrs) zones** — the blue tint separates cleanly from everything else

**Not reliably extractable:** green (18-24) vs yellow (02-04).

The zone tints are semi-transparent washes composited onto satellite imagery — the page is one raster sliced into 115 strips, so there's no separate overlay layer to read. And the basemap is *itself* green over vegetation, which swamps a green tint. I tried two methods (median sampling and bright-surface sampling); both put vegetated zones and green-tinted zones in the same place. I'm not going to hand you a number I can't stand behind.

**So: `extract_esr_supply.py`** (attached) does the reliable part on all 37 maps locally, renders a preview PNG of each, and writes a CSV where every uncertain row is marked `CHECK`. **Someone opens the previews and fills the green/yellow calls by eye — about a minute per map, so under an hour for all 37.**

That's the right division: the machine does structure, a human does the three-way colour judgement it's actually good at. And the output is a dataset nobody else has.

---

## 3. Georeferencing — the honest position

The boundaries are vector, but there's **no georeferencing in the PDFs** — no coordinate grid, no graticule. To place them on a real map you need control points.

**Don't try to georeference all 37.** For the demo, hand-trace approximate command-area boundaries in geojson.io for the 4–6 ESRs you'll actually show, using the satellite basemap to align. An hour, and it's enough. Label them "approximate, digitised from OCW published maps" — which is both honest and fine.

---

## 4. What I fetched for you already

- **347 CGWB groundwater samples** — coordinates, full chemistry incl. SAR and RSC ✅
- **NEERI 2023-24**: 23 river sites, 12 city wells, 10 lakes, 13 STPs — chemistry, coliforms, metals ✅
- **15 raw tables** from the ESR water chapter ✅
- **48-feature GeoJSON** ready to map ✅
- Supply-zone structure for the 8 maps I could stage ✅

---

## 5. What I cannot get from here — you'll need to do these

| # | What | Why I can't | How long |
|---|---|---|---|
| 1 | **Run `extract_esr_supply.py` + the eyeball pass** | File staging times out on 37 files; and the colour call needs human eyes | ~1 hr |
| 2 | **`nagpur.gov.in/disaster-management/`** | Blocked by robots.txt from this environment | 10 min |
| 3 | **MPCB NRCD STP status page** | Same restriction likely | 10 min |
| 4 | **Hand-trace 4–6 ESR boundaries** in geojson.io | Needs visual judgement | 1 hr |
| 5 | **r/nagpur harvest** — flooding and water complaints with localities | Not reachable from here | 30 min |
| 6 | **NMC ward/zone boundaries as GeoJSON** | Need to find the source | 20 min |
| 7 | **Email OCW asking for zone-level quality data** | Only you can send it | 10 min — **and saying you asked is worth points on stage** |

---

## 6. Still to process from what you've already got

- **`ESR_Report_22-23.pdf`** ⭐ — the previous year's NEERI report. Same tables, same parser → **year-on-year trend**. One year is a snapshot; two is a direction. Highest-value item remaining.
- The two academic papers — groundwater near the Nag, and the 2026 surface-water assessment. Independent corroboration plus extra sampling points.
- `MPR_Merged_Oct_2025.pdf` and the unnamed numbered PDFs — not yet identified.
- Lake sampling coordinates (Table 6.4) — chemistry is extracted, locations aren't yet.

---

## 7. On the OCWGIS app

Your scan was right and so was your conclusion: it's an authenticated internal ESRI app for utility staff, and no endpoint is exposed. **Leave it there.** Probing an authenticated municipal system is the kind of thing that turns a good project into a problem, and it would gain you nothing you can use on stage.

The legitimate version of the same idea: many Indian ULBs publish **public** ArcGIS REST / ArcGIS Hub open-data endpoints. Searching for a *published* NMC or OCW open-data service is completely fair game, and if one exists it would hand you ward boundaries and possibly the ESR polygons directly. Worth fifteen minutes.
